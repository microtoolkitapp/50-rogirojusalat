package islam.rogirojusalat.com;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

public class MainActivity extends AppCompatActivity {
    private ConsentInformation consentInformation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //admob popup
        ConsentRequestParameters params = new ConsentRequestParameters
                .Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();
        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(this,params,(ConsentInformation.OnConsentInfoUpdateSuccessListener) () -> {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(this,(ConsentForm.OnConsentFormDismissedListener) loadAndShowError -> {
                        if (loadAndShowError != null) {
                        }
                    }
            );
        },(ConsentInformation.OnConsentInfoUpdateFailureListener) requestConsentError -> {});
        getOnBackPressedDispatcher().addCallback(this, backPressedCallback);
    }
    private final OnBackPressedCallback backPressedCallback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            onBackPressedn();
        }
    };
    public void onBackPressedn() {
        new AlertDialog.Builder(this)
                .setTitle("Do you want to exit?")
                .setMessage("Thank You For Using Our Application Please Give Us Your Feedback")
                .setCancelable(true)
                .setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MainActivity.this.finish();
                    }
                })
                .setPositiveButton("Rate Us", new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int id) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
                }})
                .setNeutralButton("No", null)
                .show();
    }

    public void open(View view) {
        Intent int1 = new Intent(MainActivity.this, Dashboard.class);
        startActivity(int1);
    }
    public void rating(View view) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
    }
    public void share(View view) {
        //share
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody = getResources().getString(R.string.app_name)+" . https://play.google.com/store/apps/details?id="+getPackageName();
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }
    public void more(View view) {
        Intent int2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName()));
        startActivity(int2);
    }

    public void report(View view) {
        Intent mailIntent = new Intent(Intent.ACTION_VIEW);
        Uri data = Uri.parse("mailto:?subject=" + "Report for '"+getResources().getString(R.string.app_name)+"' "+ "&body=" + "Dear please type your problem" + "&to=" + "shahinalam6644@gmail.com");
        mailIntent.setData(data);
        startActivity(Intent.createChooser(mailIntent, "Send mail..."));
    }
    public void update(View view) {
        Intent int2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName()));
        startActivity(int2);
    }
    public void exite(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Do you want to exit?")
                .setMessage("Thank You For Using Our Application Please Give Us Your Feedback")
                .setCancelable(true)
                .setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MainActivity.this.finish();
                    }
                })
                .setPositiveButton("Rate Us", new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int id) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
                }})
                .setNeutralButton("No", null)
                .show();
    }
    public void about(View view) {
        Intent int1 = new Intent(MainActivity.this, AboutUS.class);
        startActivity(int1);
    }
}
